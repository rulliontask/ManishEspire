package com.task.taskscheduler;

import java.util.List;
import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
    
    	TaskScheduling task = new TaskScheduling();
    	try (Scanner sc = new Scanner(System.in)) {
			System.out.println("Please enter tasks like - a,b,c,d");
			String tasks = sc.nextLine();
			String dependency="";
			if(!tasks.isEmpty()) {
				System.out.println("Please enter dependancies like - a=>b,c=>d,a=>d -");
				dependency = sc.nextLine();
			}

			System.out.println("Task : "+tasks);
			System.out.println("Dependancies : "+dependency);

			List<String> result = null;
			try {
				result = task.findOrder(tasks,dependency);
				System.out.println("result: " + result);
			} catch (Exception e) {
				System.out.println(e.getMessage()) ;
				e.printStackTrace();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
}
