package com.task.exception;

public class CyclicDependancyException extends RuntimeException{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public CyclicDependancyException(String error) {
		super(error);
	}

}
