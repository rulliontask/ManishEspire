package com.task.taskscheduler;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.task.exception.CyclicDependancyException;


public class TaskSchedulerTest {
	
	TaskScheduling task ;
	
	 @Before
	  public void setUp() {
	    task = new TaskScheduling();
	  }

	  @Test
	  public void dependencyTest1() {
		  List<String> result =
	    		task.findOrder("","");
	    assertEquals("[]", result.toString());
	  }

	  @Test
	  public void dependencyTest2() {
		  List<String> result =
		    		task.findOrder("a,b,c", "");
	    assertEquals("[a, b, c]", result.toString());
	  }

	  @Test
	  public void dependencyTest3() {
		  List<String> result =
		    		task.findOrder("a,b", "a=>b");
	    assertEquals("[b, a]", result.toString());
	  }

	  @Test
	  public void dependencyTest4() {
		  List<String> result =
		    		task.findOrder("a,b,c,d", "a=>b,c=>d");
	    assertEquals("[b, a, d, c]", result.toString());
	  }

	  @Test
	  public void dependencyTest5() {
		  List<String> result =
		    		task.findOrder("a,b,c", "a=>b,b=>c");
	    assertEquals("[c, b, a]", result.toString());
	  }

	  @Test(expected = CyclicDependancyException.class)
	  public void dependencyTest6() {
		    task.findOrder("a,b,c,d","a=>b,b=>c,c=>d,d=>a");
	  }

}
