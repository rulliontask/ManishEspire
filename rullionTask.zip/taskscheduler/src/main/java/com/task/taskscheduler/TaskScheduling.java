package com.task.taskscheduler;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.task.exception.CyclicDependancyException;

public class TaskScheduling {

	String[] result;

	// state of task
	static String NEW = "NEW";
	static String INPROGRESS = "INPROGRESS";
	static String PROCESSED = "PROCESSED";

	Map<String, String> taskMap;
	Map<String, List<String>> dependancyMap;
	List<String> order;

	boolean isCyclic;

	private void initialise(List<String> tasks, List<String> dependencies) {
		taskMap = new HashMap<String, String>();
		dependancyMap = new HashMap<String, List<String>>();
		
		isCyclic = false;
		// initialise status of all task as new
		tasks.forEach((task) -> taskMap.put(task.toString(), NEW));

		// make list of dependancies for each task
		if (dependencies.size() != 0) {
			for (String s : dependencies) {
				String[] key = s.split("=>");
				List<String> list = dependancyMap.getOrDefault(key[0], new ArrayList<String>());
				list.add(key[1]);
				dependancyMap.put(key[0], list);
			}
		}
		

	}

	public List<String> findOrder(String taskInput, String dependancyInput) {
		List<String> tasks;
		List<String> dependancy = new ArrayList<String>();
		order = new ArrayList<String>();
		if(!taskInput.isEmpty()) {
			tasks = Stream.of(taskInput.split(",")).collect(Collectors.toList());
			if(!dependancyInput.isEmpty())
				dependancy= Stream.of(dependancyInput.split(",")).collect(Collectors.toList());
			this.initialise(tasks, dependancy);
	
			// start processing tasks one by one
			taskMap.entrySet().stream().forEach(e -> {
				if (!isCyclic && e.getValue().equals(NEW))
					this.search(e.getKey());
			});
		}

		return order;
	}

	private void search(String node) {
		taskMap.put(node, INPROGRESS);
		List<String> nodeDependancy = dependancyMap.getOrDefault(node, new ArrayList<String>());

		nodeDependancy.forEach(dependancy -> {
			if (taskMap.get(dependancy).equals(INPROGRESS))
				isCyclic = true;
			else if (taskMap.get(dependancy).equals(NEW))
				search(dependancy);
		});

		if (!isCyclic) {
			taskMap.put(node, PROCESSED);
			order.add(node);
		} else
			throw new CyclicDependancyException("Exception - tasks has cyclic dependancy");

	}

}
