package com.task.taskscheduler;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Before;
import org.junit.Test;

import com.task.exception.CyclicDependancyException;


public class TaskSchedulerTest {
	
	TaskScheduling task ;
	
	 @Before
	  public void init() {
	    task = new TaskScheduling();
	  }

	  @Test
	  public void testWithNoTasks() {
		  List<String> result =
	    		task.findOrder("","");
	    assertEquals("[]", result.toString());
	  }

	  @Test
	  public void testWithTasksOnly() {
		  List<String> result =
		    		task.findOrder("a,b", "");
	    assertEquals("[a, b]", result.toString());
	  }
	  
	  @Test
	  public void testWithTaskAndDependency() {
		  List<String> result =
		    		task.findOrder("a,b", "a=>b");
	    assertEquals("[b, a]", result.toString());
	  }

	  @Test
	  public void testWithTasksAndDependencies() {
		  List<String> result =
		    		task.findOrder("a,b,c,d", "a=>b,c=>d");
	    assertEquals("[b, a, d, c]", result.toString());
	  }
	  
	  @Test
	  public void testWithTransitiveDependancy() {
		  List<String> result =
		    		task.findOrder("a,b,c", "a=>b,b=>c");
	    assertEquals("[c, b, a]", result.toString());
	  }
	  
	  @Test(expected = CyclicDependancyException.class)
	  public void testWithCyclicDependancy() {
		    task.findOrder("a,b,c,d","a=>b,b=>c,c=>a");
	  }

	  

	  

}
